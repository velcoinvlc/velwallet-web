import { WalletApp } from './sections/WalletApp';

function App() {
  return <WalletApp />;
}

export default App;
